package com.springone.ioc;

import java.util.ArrayList;

public class Cart {

	private ArrayList<Product> productList;

	public ArrayList<Product> getProductList() {
		return productList;
	}

	public void setProductList(ArrayList<Product> productList) {
		this.productList = productList;
	}
	
	
}
