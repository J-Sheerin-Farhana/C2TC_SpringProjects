//Program to demonstrate configuration using annotations


package com.springannotations.application;

import org.springframework.context.annotation.ComponentScan;



@ComponentScan({"com.springannotations"})
public class ApplicationConfig {

}
