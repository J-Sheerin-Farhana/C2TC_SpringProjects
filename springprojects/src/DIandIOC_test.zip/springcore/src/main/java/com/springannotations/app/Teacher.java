//Program to implement Dependency Injection using setter through annotations



package com.springannotations.app;

public interface Teacher {
	public String getTeacherInfo();
	
}
